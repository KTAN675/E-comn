import 'dart:ui';
import 'package:get/get.dart';
import '../../constant/app_colors.dart';

enum AppMode {
  grocery,
  medicine,
}

class ThemeController extends GetxController {

  /// =============================
  /// APP MODE
  /// =============================

  AppMode currentMode = AppMode.grocery;

  bool get isGrocery => currentMode == AppMode.grocery;

  /// =============================
  /// ACCENT COLOR
  /// =============================

  Color currentAccent = AppColors.primaryOrange;

  /// =============================
  /// TOGGLE MODE (GLOBAL)
  /// =============================

  void toggleMode() {

    if (currentMode == AppMode.grocery) {
      currentMode = AppMode.medicine;

      /// optional theme change
      currentAccent = AppColors.secondaryCyan;

      /// if you use color themes
      AppColors.setMedicineTheme();

    } else {
      currentMode = AppMode.grocery;

      currentAccent = AppColors.primaryOrange;

      AppColors.setGroceryTheme();
    }

    update();
  }

  /// =============================
  /// CHANGE ACCENT MANUALLY
  /// =============================

  void changeAccent(Color newColor) {
    currentAccent = newColor;
    update();
  }
}