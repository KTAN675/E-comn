import 'package:flutter/material.dart';
import '../../../constant/app_colors.dart';
import '../../../constant/app_text_styles.dart';
import '../../../data/models/product/product_model.dart';

class CartItemCard extends StatelessWidget {
  final ProductModel product;

  const CartItemCard({
    super.key,
    required this.product,
  });

  @override
  Widget build(BuildContext context) {

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Row(
        children: [

          /// IMAGE
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.asset(
              product.image,
              width: 70,
              height: 70,
              fit: BoxFit.cover,
            ),
          ),

          const SizedBox(width: 12),

          /// DETAILS
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                Text(
                  product.title,
                  style: AppTextStyles.bodyLarge.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),

                const SizedBox(height: 4),

                Text(
                  product.weight,
                  style: AppTextStyles.bodyGrey,
                ),

                const SizedBox(height: 6),

                Text(
                  "Move to Wishlist",
                  style: AppTextStyles.caption.copyWith(
                    decoration: TextDecoration.underline,
                  ),
                ),
              ],
            ),
          ),

          /// QTY + PRICE
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [

              /// STEPPER
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                height: 36,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: const Color(0xffF1F1F1),
                ),
                child: Row(
                  children: const [
                    Icon(Icons.remove, size: 18),
                    SizedBox(width: 12),
                    Text("1"),
                    SizedBox(width: 12),
                    Icon(Icons.add, size: 18, color: AppColors.primaryOrange),
                  ],
                ),
              ),

              const SizedBox(height: 10),

              Row(
                children: [

                  Text(
                    "₹${product.oldPrice?.toStringAsFixed(0) ?? ""}",
                    style: AppTextStyles.strikePrice,
                  ),

                  const SizedBox(width: 6),

                  Text(
                    "₹${product.price.toStringAsFixed(0)}",
                    style: AppTextStyles.price.copyWith(
                      color: Colors.green,
                    ),
                  ),
                ],
              ),
            ],
          )
        ],
      ),
    );
  }
}