import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../cart_controller.dart';

class OrderSummarySection extends GetView<CartController> {
  const OrderSummarySection({super.key});

  @override
  Widget build(BuildContext context) {

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: const Color(0xffF7F7F7),
        ),
        child: Column(
          children: [

            _row("Order Amount", "₹30"),
            _row("Promo-code", "₹3"),
            _row("Delivery", "₹1"),
            _row("Tax", "₹30"),

            const Divider(),

            _row(
              "Total Amount",
              "\$${controller.totalAmount}",
              bold: true,
            ),
          ],
        ),
      ),
    );
  }

  Widget _row(String title, String value, {bool bold = false}) {

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [

          Text(
            title,
            style: TextStyle(
              fontWeight: bold ? FontWeight.bold : FontWeight.normal,
            ),
          ),

          Text(
            value,
            style: TextStyle(
              fontWeight: bold ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ],
      ),
    );
  }
}