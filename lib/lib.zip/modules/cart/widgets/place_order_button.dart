import 'package:flutter/material.dart';
import '../../../utils/app_primary_button.dart';

class PlaceOrderButton extends StatelessWidget {
  const PlaceOrderButton({super.key});

  @override
  Widget build(BuildContext context) {

    return Container(
      padding: const EdgeInsets.all(16),
      child: AppPrimaryButton(
        title: "Place Order",
        onTap: () {},
      ),
    );
  }
}