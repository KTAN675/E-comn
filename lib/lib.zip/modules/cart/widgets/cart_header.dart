import 'package:flutter/material.dart';
import 'package:get/get.dart';

class CartHeader extends StatelessWidget {
  const CartHeader({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: 16,
        vertical: 12,
      ),
      child: Row(
        children: [

          GestureDetector(
            onTap: () => Get.back(),
            child: const Icon(Icons.arrow_back),
          ),

          const SizedBox(width: 12),

          const Text(
            "Cart",
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}