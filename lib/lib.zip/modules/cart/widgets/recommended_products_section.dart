import 'package:flutter/material.dart';
import '../../../data/models/product/product_model.dart';
import '../../products/widgets/product_card_medium.dart';

class RecommendedProductsSection extends StatelessWidget {

  const RecommendedProductsSection({super.key});

  @override
  Widget build(BuildContext context) {

    List<ProductModel> products = [];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          const Text(
            "You may also like",
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
          ),

          const SizedBox(height: 12),

          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: products.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: .72,
              mainAxisSpacing: 14,
              crossAxisSpacing: 12,
            ),
            itemBuilder: (_, i) {

              return ProductCardMedium(
                product: products[i],
                accent: Colors.orange,
                discountColor: Colors.red,
              );
            },
          ),
        ],
      ),
    );
  }
}