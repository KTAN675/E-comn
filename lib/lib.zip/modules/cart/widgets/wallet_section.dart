import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../cart_controller.dart';

class WalletSection extends GetView<CartController> {
  const WalletSection({super.key});

  @override
  Widget build(BuildContext context) {

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: const Color(0xffF7F7F7),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            Text("Wallet Balance : ₹${controller.walletBalance}"),

            const SizedBox(height: 10),

            Row(
              children: [

                Checkbox(
                  value: controller.walletApplied,
                  onChanged: (_) {
                    controller.toggleWallet();
                  },
                ),

                const Text("Apply Wallet"),
              ],
            ),
          ],
        ),
      ),
    );
  }
}