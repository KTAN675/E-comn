import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../cart_controller.dart';

class PaymentMethodsSection extends GetView<CartController> {
  const PaymentMethodsSection({super.key});

  @override
  Widget build(BuildContext context) {

    final methods = [
      "UPI",
      "Card",
      "Net Banking",
      "Cash on Delivery"
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: List.generate(
          methods.length,
              (index) {

            return ListTile(
              title: Text(methods[index]),
              trailing: Radio(
                value: index,
                groupValue: controller.selectedPaymentIndex,
                onChanged: (value) {
                  controller.selectPayment(index);
                },
              ),
            );
          },
        ),
      ),
    );
  }
}