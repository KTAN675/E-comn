import 'package:get/get.dart';
import '../../data/models/product/product_model.dart';

class CartController extends GetxController {

  /// CART ITEMS
  List<ProductModel> cartItems = [];

  /// PAYMENT
  int selectedPaymentIndex = 0;

  void selectPayment(int index) {
    selectedPaymentIndex = index;
    update();
  }

  /// WALLET
  bool walletApplied = true;
  double walletBalance = 300;

  void toggleWallet() {
    walletApplied = !walletApplied;
    update();
  }

  /// TOTAL
  double get totalAmount {
    double total = 0;
    for (var item in cartItems) {
      total += item.price;
    }
    return total;
  }
}