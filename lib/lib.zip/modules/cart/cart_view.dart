import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../constant/app_colors.dart';
import 'cart_controller.dart';
import 'widgets/cart_header.dart';
import 'widgets/cart_items_section.dart';
import 'widgets/recommended_products_section.dart';
import 'widgets/payment_methods_section.dart';
import 'widgets/delivery_address_card.dart';
import 'widgets/wallet_section.dart';
import 'widgets/order_summary_section.dart';
import 'widgets/place_order_button.dart';

class CartView extends GetView<CartController> {
  const CartView({super.key});

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        bottom: false,
        child: GetBuilder<CartController>(
          builder: (controller) {

            return Column(
              children: [

                /// HEADER
                const CartHeader(),

                /// SCROLLABLE AREA
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      children: const [

                        CartItemsSection(),

                        SizedBox(height: 16),

                        RecommendedProductsSection(),

                        SizedBox(height: 20),

                        PaymentMethodsSection(),

                        SizedBox(height: 20),

                        DeliveryAddressCard(),

                        SizedBox(height: 20),

                        WalletSection(),

                        SizedBox(height: 20),

                        OrderSummarySection(),

                        SizedBox(height: 100),
                      ],
                    ),
                  ),
                ),

                /// PLACE ORDER BUTTON
                const PlaceOrderButton(),
              ],
            );
          },
        ),
      ),
    );
  }
}