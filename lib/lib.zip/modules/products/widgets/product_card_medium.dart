import 'package:flutter/material.dart';
import '../../../constant/app_text_styles.dart';
import '../../../data/models/product/product_model.dart';

class ProductCardMedium extends StatelessWidget {
  final ProductModel product;
  final Color accent;
  final Color discountColor;
  final VoidCallback? onAdd;

  const ProductCardMedium({
    super.key,
    required this.product,
    required this.accent,
    required this.discountColor,
    this.onAdd,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 210,
      decoration: BoxDecoration(
        color: const Color(0xFFF4F4F4),
        borderRadius: BorderRadius.circular(26),
      ),
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          /// IMAGE
          Stack(
            children: [
              AspectRatio(
                aspectRatio: 1.3,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(18),
                  child: Image.asset(
                    product.image,
                    fit: BoxFit.cover,
                  ),
                ),
              ),

              if (product.discount != null)
                Positioned(
                  right: 8,
                  top: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: discountColor,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      "${product.discount}%",
                      style: AppTextStyles.caption.copyWith(
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
            ],
          ),

          const SizedBox(height: 12),

          Text(
            product.title,
            style: AppTextStyles.bodyLarge.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),

          const SizedBox(height: 4),

          Text(
            product.subtitle ?? "",
            style: AppTextStyles.bodyGrey,
          ),

          const SizedBox(height: 4),

          Text(
            product.weight,
            style: AppTextStyles.bodyGrey,
          ),

          const SizedBox(height: 10),

          Row(
            children: [
              Text(
                "₹${product.price.toStringAsFixed(2)}",
                style: AppTextStyles.price,
              ),
              const SizedBox(width: 6),
              if (product.oldPrice != null)
                Text(
                  "₹${product.oldPrice!.toStringAsFixed(2)}",
                  style: AppTextStyles.strikePrice,
                ),
              const Spacer(),
              GestureDetector(
                onTap: onAdd,
                child: Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: accent,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.add, color: Colors.white),
                ),
              )
            ],
          ),
        ],
      ),
    );
  }
}