import 'package:e_comm/modules/products/product_detail/product_detail_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../constant/app_colors.dart';
import 'widgets/product_header.dart';
import 'widgets/product_image_card.dart';
import 'widgets/product_info_section.dart';
import 'widgets/product_price_stepper.dart';
import 'widgets/product_description.dart';
import 'widgets/product_action_buttons.dart';

class ProductDetailView extends GetView<ProductDetailController> {
  const ProductDetailView({super.key});

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: AppColors.background,

      body: SafeArea(
        child: GetBuilder<ProductDetailController>(
          builder: (controller) {

            final product = controller.product;

            return Column(
              children: [

                /// SCROLLABLE CONTENT
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [

                        ProductHeader(
                          onBack: () => Get.back(),
                        ),

                        ProductImageCard(
                          image: product.image,
                        ),

                        const SizedBox(height: 16),

                        ProductInfoSection(
                          title: product.title,
                          shop: "Farm Shop",
                        ),

                        const SizedBox(height: 12),

                        ProductPriceStepper(
                          price: product.price,
                          oldPrice: product.oldPrice ?? 0,
                          qty: controller.quantity,
                          onAdd: controller.increaseQty,
                          onRemove: controller.decreaseQty,
                        ),

                        const Divider(),

                        ProductDescription(
                          description:
                          "Strawberries need to be stored in a cool and dry place after they have been picked.",
                        ),

                        const SizedBox(height: 80),
                      ],
                    ),
                  ),
                ),

                /// BOTTOM ACTION BUTTONS
                const ProductActionButtons(),
              ],
            );
          },
        ),
      ),
    );
  }
}