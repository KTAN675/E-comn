import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../constant/app_colors.dart';
import '../../../data/models/product/product_model.dart';

class ProductDetailController extends GetxController {

  late ProductModel product;

  int quantity = 1;

  @override
  void onInit() {
    super.onInit();

    final args = Get.arguments;

    if (args is ProductModel) {
      product = args;
    } else {
      throw Exception("ProductDetail requires ProductModel");
    }
  }

  void increaseQty() {
    quantity++;
    update();
  }

  void decreaseQty() {
    if (quantity > 1) {
      quantity--;
      update();
    }
  }

  Color get accent => AppColors.accent;
}