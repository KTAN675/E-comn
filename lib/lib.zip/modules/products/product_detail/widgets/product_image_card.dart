import 'package:flutter/material.dart';

class ProductImageCard extends StatelessWidget {

  final String image;

  const ProductImageCard({
    super.key,
    required this.image,
  });

  @override
  Widget build(BuildContext context) {

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Center(
        child: Image.asset(
          image,
          height: 200,
          fit: BoxFit.contain,
        ),
      ),
    );
  }
}