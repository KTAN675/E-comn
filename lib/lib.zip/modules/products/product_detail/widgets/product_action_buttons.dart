import 'package:flutter/material.dart';
import '../../../../constant/app_colors.dart';
import '../../../../constant/app_text_styles.dart';

class ProductActionButtons extends StatelessWidget {

  const ProductActionButtons({super.key});

  @override
  Widget build(BuildContext context) {

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [

          Expanded(
            child: OutlinedButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.shopping_cart),
              label: Text(
                "Add to Cart",
                style: AppTextStyles.buttonSecondary,
              ),
            ),
          ),

          const SizedBox(width: 12),

          Expanded(
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryOrange,
              ),
              onPressed: () {},
              child: Text(
                "Buy Now",
                style: AppTextStyles.button,
              ),
            ),
          ),
        ],
      ),
    );
  }
}